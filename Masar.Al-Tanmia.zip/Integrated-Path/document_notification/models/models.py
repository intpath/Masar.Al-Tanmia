# -*- coding: utf-8 -*-

from enum import unique
from odoo import models, fields, api

class DocumentDocument(models.Model):
    _inherit = 'documents.document'

    notification_group_id = fields.Many2one('document.notification.group', string='Notification Group', compute = "_compute_notification_group_id", store = True)

    @api.constrains("folder_id")
    def _compute_notification_group_id(self):
        for record in self:
            record.notification_group_id = self.env["document.notification.group"].search([("folder_id", "=", record.folder_id.id)], limit=1)
            self.notify_users()

    def notify_users(self):
        for record in self:
            if record.notification_group_id:
                for user in record.notification_group_id.users:
                     record.message_post(
                        body="New Document Uploaded",
                        partner_ids=[user.partner_id.id], 
                        subject="Document Notification", 
                        message_type="notification", 
                        subtype_id=self.env.ref("mail.mt_comment").id
                    )

class DocumentNotificationGroup(models.Model):
    _name = 'document.notification.group'
    _description = 'Document Notification Group'
    _sql_constraints = [
        ('folder_id_uniq', 'unique (folder_id)', "A Group with the same workspace already exists!"),
    ]

    name = fields.Char(string="Group Name", required=True)
    users = fields.Many2many('res.users', string="Users",required=True)
    folder_id = fields.Many2one('documents.folder', string="Workspace",required=True)

    

