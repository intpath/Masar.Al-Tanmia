Copyright (C) 2022 Integrated-Path info@int-path.com



The Document Notification project can not be copied and/or distributed without the express
permission of Integrated-Path info@int-path.com.