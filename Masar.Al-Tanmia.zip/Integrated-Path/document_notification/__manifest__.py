# -*- coding: utf-8 -*-
{
    'name': "Document Notifications",
    'summary': """ Odoo custom models that notifies users on document upload """,
    'description': """ Odoo custom models that notifies users on document upload """,
    'author': "AhmedNaseem@IntegratedPath",
    'website': "https://www.int-path.com",
    'category': 'Uncategorized',
    'version': '0.0',
    'depends': ['base','documents'],
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
        'views/document_notification_groups_views.xml'
    ],

    'license': 'Other proprietary',

}

