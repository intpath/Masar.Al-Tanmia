from faker import Faker
from odoo.tests import common, tagged
from odoo.tests.common import Form
faker = Faker()



@tagged('standard', 'at_install')
class DocumentExtTest(common.TransactionCase):

    def _create_document_form(self, **kwargs):
        document_form = Form(self.env['documents.document'])
        for key,value in kwargs.items():
            setattr(document_form, key, value)
        return document_form

    def test_create_document(self):
        data = {
            # Default fields
            'name': faker.bothify(text='########'),
            'folder_id': self.env['documents.folder'].create({'name': faker.bothify(text='########')}),
            # Custom fields
            'subject': faker.bothify(text='########'),
            'to_contact_id': self.env['document.contact'].create({'name': faker.bothify(text='########')}),
            'from_contact_id': self.env['document.contact'].create({'name': faker.bothify(text='########')}),
            'document_sequence': faker.bothify(text='########'),
            'date': faker.date(pattern="%Y-%m-%d"),
            'document_number': faker.bothify(text='########'),
        }
        document_form = self._create_document_form(**data)
        record = document_form.save()