odoo.define('esign_customization.DocumentsInspector', function (require) {
    'use strict';
    
    const { _t, qweb } = require('web.core');
    const {Markup} = require('web.utils');
    const fieldRegistry = require('web.field_registry');
    const session = require('web.session');
    const { str_to_datetime } = require('web.time');
    const dialogs = require('web.view_dialogs');
    const Widget = require('web.Widget');
    
    const TAGS_SEARCH_LIMIT = 8;


    const DocumentsInspector = require('documents.DocumentsInspector')
    
    DocumentsInspector.include({
        _renderFields: function () {
            const options = {mode: 'edit'};
            const proms = [];
            if (this.records.length === 1) {
                proms.push(this._renderField('name', options));
                if (this.records[0].data.type === 'url') {
                    proms.push(this._renderField('url', options));
                }
                proms.push(this._renderField('partner_id', options));
                proms.push(this._renderField('subject', options));
                proms.push(this._renderField('to_contact_id', options));
                proms.push(this._renderField('from_contact_id', options));
                proms.push(this._renderField('document_sequence', options));
                proms.push(this._renderField('date', options));
                proms.push(this._renderField('document_number', options));
            }
            if (this.records.length > 0) {
                proms.push(this._renderField('owner_id', options));
                proms.push(this._renderField('folder_id', {
                    icon: 'fa fa-folder o_documents_folder_color',
                    mode: 'edit',
                }));
            }
            return Promise.all(proms);
        },
    })
    
});
    