# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Document(models.Model):
    _inherit = 'documents.document'

    subject = fields.Char()
    to_contact_id = fields.Many2one(
        'document.contact',
        string = 'To Contact'
    )
    from_contact_id = fields.Many2one(
        'document.contact',
        string='By Who',
    )
    document_sequence = fields.Char(string="Book Sequence")
    date = fields.Date()
    document_number = fields.Char(string="File Number")



class DocumentContact(models.Model):
    _name = "document.contact"

    name = fields.Char()
