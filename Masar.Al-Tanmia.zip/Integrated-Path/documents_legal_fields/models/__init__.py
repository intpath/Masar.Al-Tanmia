# -*- coding: utf-8 -*-

from . import document_document