# -*- coding: utf-8 -*-
{
    'name': " Documents Legal Fields ",
    'summary': """ Adds new fields to documents side form view.  """,
    'description': """ Adds new fields to documents side form view. """,
    'author': "AliFaleh@IntegratedPath",
    'website': "https://www.int-path.com",
    'category': 'Documents',
    'version': '15.0',
    'depends': ['base', 'documents'],
    'data': [
        'security/ir.model.access.csv',
        'views/document_document.xml',
    ],
    'license': 'Other proprietary',
    'assets': {
        'web.assets_backend': [
            'documents_legal_fields/static/src/js/documents_inspector.js',
            'documents_legal_fields/static/src/css/o_documents_inspector.css',
        ],
    },
}
