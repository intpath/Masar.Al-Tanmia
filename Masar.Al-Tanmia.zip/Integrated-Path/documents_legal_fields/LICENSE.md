Copyright (C) 2021 Integrated-Path info@int-path.com

This file is part of the {project name} project.

The {project name} project can not be copied and/or distributed without the express
permission of Integrated-Path info@int-path.com.