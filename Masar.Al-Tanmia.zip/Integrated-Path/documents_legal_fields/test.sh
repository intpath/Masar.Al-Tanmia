/home/odoo/odoo/.odoo-env/bin/python /home/odoo/odoo/odoo15/odoo/odoo-bin \
  --stop-after-init \
  --test-tags /esign_customization \
  --database 15-In-House \
  --addons-path=/home/odoo/odoo/odoo15/enterprise/,/home/odoo/odoo/odoo15/odoo/addons,/home/odoo/odoo/odoo15/c-addons \
  --log-level error