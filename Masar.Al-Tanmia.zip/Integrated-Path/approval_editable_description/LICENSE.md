Copyright (C) 2022 Integrated-Path info@int-path.com

This file is part of the approval_editable_description project.

The approval_editable_description project can not be copied and/or distributed without the express
permission of Integrated-Path info@int-path.com.