# -*- coding: utf-8 -*-

from odoo import models, fields, api

class ApprovalRequest(models.Model):
	_inherit = "approval.request"

	def open_description_wizard(self):
		self.ensure_one()
		wiz = self.env["approval.request.description"].create({
			"request_id": self.id,
			"body": self.reason
		})
		return {
			'name': 'Update Description',
			'type': 'ir.actions.act_window',
			'view_mode': 'form',
			'res_model': 'approval.request.description',
			'views': [(False, 'form')],
			# 'view_id': False,
			'target': 'new',
			'res_id': wiz.id,
		}
