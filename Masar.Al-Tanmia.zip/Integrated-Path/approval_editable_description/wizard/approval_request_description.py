from odoo import api, Command, fields, models, _

class ApprovalRequestDescription(models.TransientModel):
	_name = "approval.request.description"
	_description = "Approval Request Description"

	request_id = fields.Many2one("approval.request")
	body = fields.Html("Body")

	def write_to_request(self):
		user = self.env.user
		self.request_id.write({"reason": self.body})
		self.request_id.message_post(
			body= f"""
				The desciption was update by <a href="#" data-oe-model="res.partner" data-oe-id={user.partner_id.id}>{user.partner_id.display_name}</a>
			""",
			message_type='comment',
			subtype_id = self.env.ref('mail.mt_note').id,
		)