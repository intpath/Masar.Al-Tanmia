# -*- coding: utf-8 -*-
{
    'name': "Approval notification",
    'summary': """ apply notification for approved requests based on category """,
    'description': """ apply notification for approved requests based on category """,
    'author': "AhmedNaseem@IntegratedPath",
    'website': "https://www.int-path.com",
    'category': 'approval',
    'version': '15.0',
    'depends': ['base',
                'approvals'],
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
        'views/approval_category_views.xml'
    ],

    'license': 'Other proprietary',

}

