# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError

class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    @api.constrains('request_status')
    def request_status_change(self):
        for request in self:
            if request.request_status == "approved":
                request.send_notification()
    
    def send_notification(self):
        for request in self:
            if request.category_id.notified_ids:
                for user in request.category_id.notified_ids:
                    request.message_post(
                        body="Request Approved",
                        partner_ids=[user.partner_id.id], 
                        subject="Request Approved", 
                        message_type="notification", 
                        subtype_id=self.env.ref("mail.mt_comment").id
                    )
            else:
                pass