# -*- coding: utf-8 -*-

from odoo import models, fields, api


class ApprovalCategory(models.Model):
    _inherit = "approval.category"

    notified_ids = fields.Many2many(
        comodel_name = 'res.users',
        relation="approval_category_notified_users_rel",
        column1 = "category_id",
        column2 = "user_id", 
        string='Notified Users')

    
