from odoo.tests import common, tagged

# The test framework in odoo is quite dump. There is no clear and direct command for runing the tests
# instead your run the tests by setting tests as enables on runtime.
# so to make running tests easier, you can use one of the following 2 commands
# ```
# <python-virtualenv-path-if-needed> <odoo cli> \
#   --stop-after-init \
#   --test-tags /<module_name> \
#   --log-level warn
#   --config <conf_file_path>
# OR:
# <python-virtualenv-path-if-needed> <odoo cli> \
#   --stop-after-init \
#   --test-tags /<module_name> \
#   --database <database_name> \
#   --addons-path="<addons_path>" \
#   --log-level warn
# ```
# The result would be something like this:
# ```
# /odoo15/.odoo-env/bin/python /odoo15/odoo/odoo-bin \
#   --stop-after-init \
#   --test-tags /intpath_scaffold \
#   --database 15-demo \
#   --addons-path="/odoo15/enterprise,/odoo15/odoo/addons,/odoo15/c-addons/intpath" \
#   --log-level warn
# ```
# it is recommened to come up with a way to run the test in a single command.
# One of these methods is to create an sh file (ex: test.sh) and paste the command it
# so that you can run the test from file. Just make sure you don't add it to GitHub repo
# 
# More guides on Odoo tests can be found in these links
# https://www.odoo.com/documentation/15.0/developer/howtos/rdtraining/E_unittest.html
# https://www.odoo.com/documentation/15.0/developer/reference/backend/testing.html


@tagged('standard', 'at_install') # tags are optional 
class TestModelB(common.TransactionCase):
    def test_some_action(self):
        name = "customer name"
        record = self.env['res.partner'].create({'name': name})
        self.assertEqual(record.name, name)