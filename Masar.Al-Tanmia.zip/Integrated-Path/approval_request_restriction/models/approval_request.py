# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError


class ApprovalRequest(models.Model):
    _inherit = "approval.request"

    @api.model
    def create(self, values):
        result = super().create(values)
        category_id = values.get("category_id")
        category = self.env["approval.category"].search([("id", "=", category_id)])
        if self.env.user not in category.visibility_ids:
            raise UserError("You are not allowed to create approvel request")
        return result