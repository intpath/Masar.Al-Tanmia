# -*- coding: utf-8 -*-

from odoo import models, fields, api


class ApprovalCategory(models.Model):
    _inherit = 'approval.category'

    visibility_ids = fields.Many2many(
        'res.users', 
        string='Visibility members',
        help = 'Users that can see approvals with this category',
        groups = 'approvals.group_approval_manager'
        
        )
