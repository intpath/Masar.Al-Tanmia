# -*- coding: utf-8 -*-
{
    'name': "Approval request restriction",
    'summary': """ Odoo custom module that applies record limitation per user to the approvals model. """,
    'description': """ Odoo custom module that applies record limitation per user to the approvals model. """,
    'author': "AhmedNaseem@IntegratedPath",
    'website': "https://www.int-path.com",
    'category': 'approvals',
    'version': '15.0',
    'depends': ['base',
                'approvals',],
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
        'views/approval_category_view.xml',
        'security/rules.xml'
    ],

    'license': 'Other proprietary',

}

