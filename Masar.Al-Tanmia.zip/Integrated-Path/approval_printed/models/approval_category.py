from odoo import api, fields, models


class ApprovalCategory(models.Model):
    _inherit = "approval.category"

    printed_sequence_id = fields.Many2one("ir.sequence", string="Print Sequence")
    include_hand_signature_stamp = fields.Boolean("Include Hand Signature Stamp")
    include_project_manager_signature = fields.Boolean(
        "Include Project Manager Signature"
    )
    include_executive_manager_signature = fields.Boolean("Include Executive Manager Signature") 
    hand_signature_user_id = fields.Many2one('res.users', "Hand Signature User")
    include_report_layout = fields.Many2one("ir.ui.view", "Report Layout")
    request_of_purchase_approval = fields.Boolean("Request of Purchase", default=False)
    include_approval_requester_signature = fields.Boolean(
        "Include Approval Requester Signature", default=False
    )
