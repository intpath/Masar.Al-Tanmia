from odoo import api, fields, models


class ResUsers(models.Model):
    _inherit = "res.users"

    signutare_img = fields.Image("Approvals Signature Image")
    # signutare_name = fields.Char("Approvals Signature Name")
