# -*- coding: utf-8 -*-

from odoo import api, fields, models
from odoo.exceptions import UserError


class ApprovalRequestContact(models.Model):
    _name = "approval.request.contact"
    _description = "Approval Request Contact"

    name = fields.Char("name")


class ApprovalRequestContact(models.Model):
    _name = "approval.request.attachment"
    _description = "Approval Request Contact"

    name = fields.Char("name")


class ApprovalRequested(models.Model):
    _inherit = "approval.request"

    printed_subject = fields.Char("Printed Subject", tracking=True)
    printed_sequence = fields.Char("Printed Sequence", tracking=True)
    printed_date = fields.Date("Printed Date", tracking=True)
    printed_send_to = fields.Many2many(
        "approval.request.contact",
        "request_send_to_field_rel",
        "contact_send_to_field_rel",
        "request_send_to_contact_table",
        string="Send To",
        tracking=True,
    )
    printed_from = fields.Many2one(
        "approval.request.contact", string="Send From", tracking=True
    )
    printed_copy_to = fields.Many2many(
        "approval.request.contact",
        "request_copy_to_field_rel",
        "contact_copy_to_field_rel",
        "request_copy_to_contact_table",
        string="Copy To",
        tracking=True,
    )
    printed_attchments = fields.Many2many(
        "approval.request.attachment", string="Attachments", tracking=True
    )
    document_number = fields.Char("Document Number", tracking=True)
    printed_description = fields.Html("Description")
    signature_margin = fields.Float("Signature Margin", default=10.0)

    @api.constrains("request_status")
    def update_printed_sequence_field(self):
        if self.request_status == "approved":
            if not self.printed_sequence:
                new_sequence = self.category_id.printed_sequence_id._next()
                self.printed_sequence = "".join(
                    [n for n in new_sequence if not n.isdigit()]
                ) + str(
                    int("".join([n for n in new_sequence if n.isdigit()]))
                )  # remove uneeded zero's at the beginning of the line

            if not self.printed_date:
                self.printed_date = fields.Datetime.now().date()

    def is_line_to_include_signature_img(self, approver_line):
        # Used by printed report
        related_category_approver_line = self.category_id.approver_ids.filtered(
            lambda x: x.user_id == approver_line.user_id
        )
        if related_category_approver_line:
            return related_category_approver_line.include_sig
        else:
            return False

    def check_if_report_should_be_printed(self):
        if self.request_status != "approved":
            raise UserError("You can not print a document that is not approved")


class ApprovalProductLine(models.Model):
    _inherit = "approval.product.line"

    product_type = fields.Selection(
        [
            ("commodity", "سلعة"),
            ("service", "خدمات"),
            ("technical_contracts", "عقود فنية"),
            ("consulting_contracts", "عقود استشارية"),
        ],
        string="Product Type",
    )
