from odoo import api, fields, models


class ApprovalCategoryApprover(models.Model):
    _inherit = "approval.category.approver"

    include_sig = fields.Boolean("Include Signature")
