# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import UserError


class ApprovalRequest(models.Model):
	_inherit = 'approval.request'

	user_status = fields.Selection(selection_add=[("wait", "Waiting"), ("approved",)])

	# OVERIDE FUNCTION
	def action_confirm(self):
		self.ensure_one()
		if self.category_id.manager_approval == 'required':
			employee = self.env['hr.employee'].search([('user_id', '=', self.request_owner_id.id)], limit=1)
			if not employee.parent_id:
				raise UserError(_('This request needs to be approved by your manager. There is no manager linked to your employee profile.'))
			if not employee.parent_id.user_id:
				raise UserError(_('This request needs to be approved by your manager. There is no user linked to your manager.'))
			if not self.approver_ids.filtered(lambda a: a.user_id.id == employee.parent_id.user_id.id):
				raise UserError(_('This request needs to be approved by your manager. Your manager is not in the approvers list.'))
		if len(self.approver_ids) < self.approval_minimum:
			raise UserError(_("You have to add at least %s approvers to confirm your request.", self.approval_minimum))
		if self.requirer_document == 'required' and not self.attachment_number:
			raise UserError(_("You have to attach at lease one document."))

		if self.category_id.is_sequenced_approval:
			approvers = self.approver_ids[0]
			if len(self.approver_ids) > 1:
				waiting_approvers = self.approver_ids[1:]
			else:
				waiting_approvers = None

		else:
			approvers = self.mapped('approver_ids').filtered(lambda approver: approver.status == 'new')
			waiting_approvers = None

		approvers._create_activity()
		approvers.write({'status': 'pending'})
		if waiting_approvers:
			waiting_approvers.write({'status': 'wait'})
		self.write({'date_confirmed': fields.Datetime.now()})

	def action_approve(self, approver=None):
		if self.category_id.is_sequenced_approval:
			current_approver_line = self.approver_ids.filtered(lambda x: x.status == "pending")
			if self.env.user != current_approver_line.user_id:
				raise UserError("You don't have persmission to approved this request")
		res = super().action_approve(approver)
		if self.category_id.is_sequenced_approval:
			wait_approvals = self.approver_ids.filtered(lambda x: x.status == "wait")
			if len(wait_approvals) > 0:
				next_approver = wait_approvals[0]
				next_approver.write({"status": "pending"})
				self.activity_schedule(
					'approvals.mail_activity_data_approval',
					user_id=next_approver.user_id.id
				)
		return res
