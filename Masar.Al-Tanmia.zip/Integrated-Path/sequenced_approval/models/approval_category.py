# -*- coding: utf-8 -*-

from odoo import models, fields, api


class ApprovalCategory(models.Model):
    _inherit = 'approval.category'

    is_sequenced_approval = fields.Boolean("Sequenced Approval")
