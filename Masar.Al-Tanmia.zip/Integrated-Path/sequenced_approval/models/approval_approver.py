# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import UserError

class ApprovalApprover(models.Model):
    _inherit = 'approval.approver'

    status = fields.Selection(selection_add=[("wait", "Waiting"), ("approved",)])
