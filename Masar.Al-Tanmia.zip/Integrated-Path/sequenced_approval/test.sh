/odoo15/.odoo-env/bin/python /odoo15/odoo/odoo-bin \
	--stop-after-init \
	--test-tags /sequence_approval \
	--database 15-demo-2 \
	--addons-path="/odoo15/enterprise,/odoo15/odoo/addons,/odoo15/c-addons/intpath" \
	--log-level warn