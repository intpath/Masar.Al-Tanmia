import datetime
from faker import Faker
from odoo.tests import common, tagged
from odoo.tests.common import Form
from odoo.exceptions import UserError

fake = Faker()

@tagged('standard', 'at_install')
class TestDocumentCategory(common.TransactionCase):
    def setUp(self):
        super().setUp()
        def creating_users():
            self.manager_1 = self.env.ref("base.user_admin")
            manager_2_name = fake.name()
            self.manager_2 = self.manager_1.copy({
                "name": manager_2_name,
                "login": manager_2_name.replace(' ','').lower()
            })
            self.manager_2.partner_id.email = fake.email()
            manager_3_name = fake.name()
            self.manager_3 = self.manager_1.copy({
                "name": manager_3_name,
                "login": manager_3_name.replace(' ','').lower()
            })
            self.manager_3.partner_id.email = fake.email()
        creating_users()

        def create_approval_category():
            self.approval_category = self.env["approval.category"].create({
                "name": "Standard Category",
                "is_sequenced_approval": True,
                "approval_minimum": 3,
                "approver_ids": [
                    (0, 0, {"user_id": self.manager_1.id, "required": True}),
                    (0, 0, {"user_id": self.manager_2.id, "required": True}),
                    (0, 0, {"user_id": self.manager_3.id, "required": True}),
                ]
            })
        create_approval_category()

        def create_request():
            name = fake.text(max_nb_chars=20)
            request_owner_id = self.env.ref("base.user_demo")

            request_form = Form( self.env["approval.request"] )
            request_form.name = name
            request_form.request_owner_id = request_owner_id
            request_form.category_id = self.approval_category
            request_form.date_start = datetime.datetime.now()
            request_form.date_end = datetime.datetime.now() + datetime.timedelta(days=7)
            self.approval_request = request_form.save()
        create_request()

    def test_submiting_request(self):
        self.approval_request.action_confirm()
        self.assertEqual(len(self.approval_request.approver_ids), 3, self.approval_request.approver_ids)
        self.assertEqual(len(self.approval_request.activity_ids), 1, self.approval_request.activity_ids)

        manager_1_line = self.approval_request.approver_ids[0]
        self.assertEqual(manager_1_line.user_id, self.manager_1)
        self.assertEqual(manager_1_line.required, True)
        self.assertEqual(manager_1_line.status, "pending")
        self.assertEqual(self.approval_request.activity_ids.user_id, manager_1_line.user_id)
        self.assertEqual(self.approval_request.activity_ids.activity_type_id, self.env.ref("approvals.mail_activity_data_approval"))

        manager_2_line = self.approval_request.approver_ids[1]
        self.assertEqual(manager_2_line.user_id, self.manager_2)
        self.assertEqual(manager_2_line.required, True)
        self.assertEqual(manager_2_line.status, "wait")

        manager_3_line = self.approval_request.approver_ids[2]
        self.assertEqual(manager_3_line.user_id, self.manager_3)
        self.assertEqual(manager_3_line.required, True)
        self.assertEqual(manager_3_line.status, "wait")

    def test_apporving_request(self):
        self.approval_request.action_confirm()

        # ========== FIRST APPROVAL ==========
        self.approval_request.with_user(self.manager_1).action_approve()
        self.assertEqual(len(self.approval_request.activity_ids), 1, self.approval_request.activity_ids)

        manager_1_line = self.approval_request.approver_ids[0]
        self.assertEqual(manager_1_line.user_id, self.manager_1)
        self.assertEqual(manager_1_line.status, "approved")

        manager_2_line = self.approval_request.approver_ids[1]
        self.assertEqual(manager_2_line.user_id, self.manager_2)
        self.assertEqual(manager_2_line.status, "pending")
        self.assertEqual(self.approval_request.activity_ids.user_id, manager_2_line.user_id)
        self.assertEqual(self.approval_request.activity_ids.activity_type_id, self.env.ref("approvals.mail_activity_data_approval"))

        manager_3_line = self.approval_request.approver_ids[2]
        self.assertEqual(manager_3_line.user_id, self.manager_3)
        self.assertEqual(manager_3_line.required, True)
        self.assertEqual(manager_3_line.status, "wait")

        # ========== SECOND APPROVAL ==========
        self.approval_request.with_user(self.manager_2).action_approve()
        self.assertEqual(len(self.approval_request.activity_ids), 1, self.approval_request.activity_ids)

        manager_1_line = self.approval_request.approver_ids[0]
        self.assertEqual(manager_1_line.user_id, self.manager_1)
        self.assertEqual(manager_1_line.status, "approved")

        manager_2_line = self.approval_request.approver_ids[1]
        self.assertEqual(manager_2_line.user_id, self.manager_2)
        self.assertEqual(manager_2_line.status, "approved")

        manager_3_line = self.approval_request.approver_ids[2]
        self.assertEqual(manager_3_line.user_id, self.manager_3)
        self.assertEqual(manager_3_line.status, "pending")
        self.assertEqual(self.approval_request.activity_ids.user_id, manager_3_line.user_id)
        self.assertEqual(self.approval_request.activity_ids.activity_type_id, self.env.ref("approvals.mail_activity_data_approval"))

        # ========== THIRD APPROVAL ==========
        self.approval_request.with_user(self.manager_3).action_approve()
        self.assertEqual(len(self.approval_request.activity_ids), 0, self.approval_request.activity_ids)

        manager_1_line = self.approval_request.approver_ids[0]
        self.assertEqual(manager_1_line.user_id, self.manager_1)
        self.assertEqual(manager_1_line.status, "approved")

        manager_2_line = self.approval_request.approver_ids[1]
        self.assertEqual(manager_2_line.user_id, self.manager_2)
        self.assertEqual(manager_2_line.status, "approved")

        manager_3_line = self.approval_request.approver_ids[2]
        self.assertEqual(manager_3_line.user_id, self.manager_3)
        self.assertEqual(manager_3_line.status, "approved")

        self.assertEqual(self.approval_request.request_status, "approved")
    
    def test_apporving_request_from_non_allowed_manager(self):
        self.approval_request.action_confirm()
        self.assertRaises(UserError, self.approval_request.with_user(self.manager_2).action_approve)