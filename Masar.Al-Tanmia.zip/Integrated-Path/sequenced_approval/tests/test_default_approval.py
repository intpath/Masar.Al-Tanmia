import datetime
from faker import Faker
from odoo.tests import common, tagged
from odoo.tests.common import Form

# More guides on Odoo tests can be found in these links
# https://www.odoo.com/documentation/15.0/developer/howtos/rdtraining/E_unittest.html
# https://www.odoo.com/documentation/15.0/developer/reference/backend/testing.html

fake = Faker()

@tagged('standard', 'at_install') # tags are optional 
class TestDefaultApproval(common.TransactionCase):
    def setUp(self):
        super().setUp()
        def creating_users():
            self.manager_1 = self.env.ref("base.user_admin")
            manager_2_name = fake.name()
            self.manager_2 = self.manager_1.copy({
                "name": manager_2_name,
                "login": manager_2_name.replace(' ','').lower()
            })
            manager_3_name = fake.name()
            self.manager_3 = self.manager_1.copy({
                "name": manager_3_name,
                "login": manager_3_name.replace(' ','').lower()
            })
        creating_users()

        def create_approval_category():
            self.approval_category = self.env["approval.category"].create({
                "name": "Standard Category",
                "approval_minimum": 3,
                "approver_ids": [
                    (0, 0, {"user_id": self.manager_1.id, "required": True}),
                    (0, 0, {"user_id": self.manager_2.id, "required": True}),
                    (0, 0, {"user_id": self.manager_3.id, "required": True}),
                ]
            })
        create_approval_category()

        def create_request():
            name = fake.text(max_nb_chars=20)
            request_owner_id = self.env.ref("base.user_demo")

            request_form = Form( self.env["approval.request"] )
            request_form.name = name
            request_form.request_owner_id = request_owner_id
            request_form.category_id = self.approval_category
            request_form.date_start = datetime.datetime.now()
            request_form.date_end = datetime.datetime.now() + datetime.timedelta(days=7)
            self.approval_request = request_form.save()
        create_request()

    def test_submiting_request(self):
        self.approval_request.action_confirm()
        self.assertEqual(len(self.approval_request.approver_ids), 3, self.approval_request.approver_ids)
        manager_1_line = self.approval_request.approver_ids.filtered(lambda x: x.user_id == self.manager_1)
        self.assertNotEqual(manager_1_line, False, manager_1_line)
        self.assertEqual(manager_1_line.required, True)
        self.assertEqual(manager_1_line.status, "pending")

        manager_2_line = self.approval_request.approver_ids.filtered(lambda x: x.user_id == self.manager_2)
        self.assertNotEqual(manager_2_line, False, manager_2_line)
        self.assertEqual(manager_2_line.required, True)
        self.assertEqual(manager_2_line.status, "pending")

        manager_3_line = self.approval_request.approver_ids.filtered(lambda x: x.user_id == self.manager_3)
        self.assertNotEqual(manager_3_line, False, manager_3_line)
        self.assertEqual(manager_3_line.required, True)
        self.assertEqual(manager_3_line.status, "pending")

        activites = self.approval_request.activity_ids
        self.assertEqual(len(activites), 3)

