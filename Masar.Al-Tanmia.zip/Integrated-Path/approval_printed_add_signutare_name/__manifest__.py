# -*- coding: utf-8 -*-
{
    "name": "Approval Printed Add Signutare Name",
    "summary": """ Allow printing of approve requests with some extra features """,
    "description": """ Long description """,
    "author": "MohammedSaeb@IntegratedPath",
    "website": "https://www.int-path.com",
    "category": "Approvals",
    "version": "15.1",
    "depends": ["base"],
    "data": [
        # "views/res_users_views.xml",
    ],
    "license": "Other proprietary",
}
